﻿// -----------------------------------------------------------------------
// <copyright file="TaskStatus.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex08;

/// <summary>
///  タスクのステータスを表現する文字列を管理します。
/// </summary>
public class TaskStatus
{
    public const string ToDo = "To do";
    public const string InProgress = "In progress";
    public const string Done = "Done";

    /// <summary>
    ///  タスクのステータスに応じた、並べ替えの順序を返します。
    /// </summary>
    /// <param name="status">タスクのステータス。</param>
    /// <returns>並べ替えの順序。</returns>
    public static int GetOrderNumber(string status)
    {
        return status switch
        {
            InProgress => 1,
            ToDo => 2,
            Done => 3,
            _ => 4,
        };
    }

    /// <summary>
    ///  タスクのステータス一覧を取得します。
    /// </summary>
    /// <returns>タスクのステータス一覧。</returns>
    public static IEnumerable<string> GetAll()
    {
        yield return ToDo;
        yield return InProgress;
        yield return Done;
    }

    /// <summary>
    ///  指定したタスクのステータスが定義済みかどうか示す値を取得します。
    /// </summary>
    /// <param name="status">検査する文字列。</param>
    /// <returns>定義済みの場合 true 、未定義の場合 false 。</returns>
    public static bool IsDefine(string status)
    {
        return GetAll().Any(s => status == s);
    }
}
