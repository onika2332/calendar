﻿// -----------------------------------------------------------------------
// <copyright file="TodoController.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Ex08.Data;
using Ex08.Models.Todo;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ex08.Controllers;

/// <summary>
///  To-Do リストを提供するコントローラーです。
/// </summary>
[Authorize]
public class TodoController : Controller
{
    private readonly TasksDbContext dbContext;
    private readonly ILogger<TodoController> logger;

    /// <summary>
    ///  <see cref="TodoController"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="dbContext">DbContext。</param>
    /// <param name="logger">ロガー。</param>
    public TodoController(TasksDbContext dbContext, ILogger<TodoController> logger)
    {
        this.dbContext = dbContext;
        this.logger = logger;
    }

    /// <summary>
    ///  登録したタスクのタイトルを取得または設定します。
    /// </summary>
    [TempData]
    public string? NewTitle { get; set; }

    /// <summary>
    ///  登録したタスクの期限を取得または設定します。
    /// </summary>
    [TempData]
    public string? NewDueDate { get; set; }

    /// <summary>
    ///  To-Do リストの初期画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>To-Do リスト画面のビュー。</returns>
    [HttpGet]
    public IActionResult Index()
    {
        var tasks = this.dbContext.Tasks
            .Where(task => task.Status != TaskStatus.Done || task.DueDate == null || task.DueDate >= DateTime.Today.AddDays(-3))
            .ToList();
        var model = new IndexViewModel();
        var taskViewModels = tasks
            .OrderBy(task => TaskStatus.GetOrderNumber(task.Status))
                .ThenBy(task => !task.DueDate.HasValue)
                .ThenBy(task => task.DueDate)
                .ThenByDescending(task => task.Id)
            .Select(task => new TaskViewModel
            {
                Id = task.Id,
                Title = task.Title,
                Status = task.Status,
                DueDate = task.DueDate,
            });
        model.Tasks.AddRange(taskViewModels);
        return this.View(model);
    }

    /// <summary>
    ///  タスクの登録画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>タスク登録画面のビュー。</returns>
    [HttpGet]
    public IActionResult Add()
    {
        var model = new AddViewModel();
        return this.View(model);
    }

    /// <summary>
    ///  タスクの登録を行うアクションメソッドです。
    /// </summary>
    /// <param name="model">登録するタスクの情報が設定されたビューモデル。</param>
    /// <returns><see cref="Added"/> アクションメソッドへのリダイレクト。</returns>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Add(AddViewModel model)
    {
        this.logger.LogDebug(
            EventIds.RegisterTask,
            $"タスク「{model}」を登録します。");
        if (!this.ModelState.IsValid)
        {
            return this.View(model);
        }

        var newTaskItem = new TaskItem
        {
            Title = model.Title,
            Status = TaskStatus.ToDo,
            DueDate = model.DueDate,
        };
        this.dbContext.Tasks.Add(newTaskItem);
        this.dbContext.SaveChanges();

        this.NewTitle = model.Title;
        this.NewDueDate = model.DueDate?.ToString();
        return this.RedirectToAction(nameof(this.Added));
    }

    /// <summary>
    ///  登録したタスクの情報を表示するアクションメソッドです。
    /// </summary>
    /// <returns>登録したタスクの情報を表示する画面のビュー。</returns>
    [HttpGet]
    public IActionResult Added()
    {
        if (this.NewTitle == null)
        {
            this.logger.LogInformation(
                EventIds.TaskTitleIsNull,
                $"タスクのタイトルが未設定のため、登録画面にリダイレクトします。");
            return this.RedirectToAction(nameof(this.Add));
        }

        DateTime? dueDate = this.NewDueDate == null ? null : DateTime.Parse(this.NewDueDate);
        var model = new AddedViewModel
        {
            Title = this.NewTitle,
            DueDate = dueDate,
        };
        return this.View(model);
    }

    /// <summary>
    ///  タスクの編集画面を表示するアクションメソッドです。
    /// </summary>
    /// <param name="id">編集するタスクの ID 。</param>
    /// <returns>タスク編集画面のビュー。</returns>
    [HttpGet]
    public IActionResult Edit([FromRoute] int id)
    {
        var target = this.dbContext.Tasks.Find(id);
        if (target == null)
        {
            return this.RedirectToAction("Index");
        }

        var model = new EditViewModel
        {
            Id = target.Id,
            Status = target.Status,
            Title = target.Title,
            DueDate = target.DueDate,
        };
        return this.View(model);
    }

    /// <summary>
    ///  タスクの編集を行うアクションメソッドです。
    /// </summary>
    /// <param name="id">編集するタスクの ID 。</param>
    /// <param name="model">更新するタスクの情報が設定されたビューモデル。</param>
    /// <returns><see cref="Index"/> アクションメソッドへのリダイレクト。</returns>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit([FromRoute] int id, [FromForm] EditViewModel model)
    {
        if (!this.ModelState.IsValid)
        {
            return this.View(model);
        }

        if (id != model.Id)
        {
            // URL の id パラメーターとフォームの id がずれるのは改ざんとして Not Found にする。
            return this.NotFound();
        }

        TaskItem taskItem = new TaskItem
        {
            Id = model.Id,
            Title = model.Title,
            Status = model.Status,
            DueDate = model.DueDate,
        };
        this.dbContext.Tasks.Update(taskItem);
        this.dbContext.SaveChanges();
        return this.RedirectToAction("Index");
    }
}
