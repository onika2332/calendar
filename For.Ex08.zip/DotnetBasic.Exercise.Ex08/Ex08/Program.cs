﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Ex08.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews()
    .AddSessionStateTempDataProvider();
builder.Services.AddSession();

var tasksConnectionString = builder.Configuration.GetConnectionString("TasksDbContext");
builder.Services.AddDbContext<TasksDbContext>(options =>
{
    options.UseSqlServer(tasksConnectionString);
});

var userManagementConnectionString = builder.Configuration.GetConnectionString("UserManagementDbContext");
builder.Services.AddDbContext<UserManagementDbContext>(options =>
{
    options.UseSqlServer(userManagementConnectionString);
});
builder.Services.AddDefaultIdentity<IdentityUser>()
    .AddEntityFrameworkStores<UserManagementDbContext>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");

    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseSession();

// コントローラーが未指定の場合は TodoController が使われるよう既定のルーティングを変更。
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Todo}/{action=Index}/{id?}");

app.MapRazorPages();
app.Run();
