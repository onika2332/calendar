﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementDbContext.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Ex08.Data;

/// <summary>
///  ユーザー情報を管理する DbContext です。
/// </summary>
public class UserManagementDbContext : IdentityDbContext
{
    /// <summary>
    ///  <see cref="UserManagementDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public UserManagementDbContext()
    {
    }

    /// <summary>
    ///  <see cref="UserManagementDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="options">この DbContext のオプション。</param>
    public UserManagementDbContext(DbContextOptions<UserManagementDbContext> options)
        : base(options)
    {
    }

    /// <inheritdoc/>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        ArgumentNullException.ThrowIfNull(optionsBuilder);

        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=Ex08.UserManagement;Integrated Security=True");
        }
    }
}
