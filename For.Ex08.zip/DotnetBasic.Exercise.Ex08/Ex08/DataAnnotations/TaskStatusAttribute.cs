﻿// -----------------------------------------------------------------------
// <copyright file="TaskStatusAttribute.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using System.ComponentModel.DataAnnotations;

namespace Ex08.DataAnnotations;

/// <summary>
///  タスクのステータスが定義済みであることを確認するカスタム検証属性です。
/// </summary>
public class TaskStatusAttribute : ValidationAttribute
{
    /// <inheritdoc/>
    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is null)
        {
            // 未入力の場合は検証せずに成功
            return ValidationResult.Success;
        }

        if (value is not string status)
        {
            return new ValidationResult("ステータスが文字列型ではありません。");
        }

        if (string.IsNullOrEmpty(status))
        {
            // 未入力の場合は成功
            return ValidationResult.Success;
        }

        if (!TaskStatus.IsDefine(status))
        {
            const string message = $"そのようなステータスは登録できません。";
            if (validationContext.MemberName is not null)
            {
                return new ValidationResult(message, [validationContext.MemberName]);
            }
            else
            {
                return new ValidationResult(message);
            }
        }

        return ValidationResult.Success;
    }
}
