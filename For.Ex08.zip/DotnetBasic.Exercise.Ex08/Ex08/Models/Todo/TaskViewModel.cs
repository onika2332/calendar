﻿// -----------------------------------------------------------------------
// <copyright file="TaskViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex08.Models.Todo;

/// <summary>
///  To Do リストに表示するひとつのタスクを表すビューモデルです。
/// </summary>
public class TaskViewModel
{
    /// <summary>
    ///  <see cref="TaskViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public TaskViewModel()
    {
    }

    /// <summary>
    ///  タスクの ID を取得または設定します。
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    ///  タスクのタイトルを取得または設定します。
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    ///  タスクのステータスを取得または設定します。
    /// </summary>
    public string Status { get; set; } = string.Empty;

    /// <summary>
    ///  タスクの期限を取得または設定します。
    /// </summary>
    public DateTime? DueDate { get; set; }

    /// <summary>
    ///  このタスクが完了しているかどうか表す値を取得します。
    /// </summary>
    /// <returns>タスクが完了していれば <see langword="true"/> 、未完了なら <see langword="false"/> 。</returns>
    public bool IsCompleted()
    {
        return this.Status == TaskStatus.Done;
    }
}
