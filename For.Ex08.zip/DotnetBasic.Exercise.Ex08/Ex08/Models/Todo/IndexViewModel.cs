﻿// -----------------------------------------------------------------------
// <copyright file="IndexViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex08.Models.Todo;

/// <summary>
///  TodoController の Index アクションメソッドが利用するビューのビューモデルです。
/// </summary>
public class IndexViewModel
{
    /// <summary>
    ///  <see cref="IndexViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public IndexViewModel()
    {
    }

    /// <summary>
    ///  表示するタスクの一覧を取得または設定します。
    /// </summary>
    public List<TaskViewModel> Tasks { get; set; } = [];
}
