﻿// -----------------------------------------------------------------------
// <copyright file="EditViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using System.ComponentModel.DataAnnotations;
using Ex08.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Ex08.Models.Todo;

/// <summary>
///  TodoController の Edit アクションメソッドが利用するビューのビューモデルです。
/// </summary>
public class EditViewModel
{
    /// <summary>
    ///  ビューモデルを初期化します。
    /// </summary>
    public EditViewModel()
    {
        this.StatusList = TaskStatus.GetAll()
            .Select(status => new SelectListItem { Value = status, Text = status })
            .ToList();
    }

    /// <summary>
    ///  タスクの ID を取得または設定します。
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    ///  作成するタスクのタイトルを取得または設定します。
    /// </summary>
    [StringLength(maximumLength: 128, MinimumLength = 3, ErrorMessage = "タスクのタイトルは 3 文字以上 128 文字以内で入力してください。")]
    [Required(ErrorMessage = "タスクのタイトルの入力は必須です。")]
    public string Title { get; set; } = string.Empty;

    /// <summary>
    ///  タスクのステータスを取得または設定します。
    /// </summary>
    [TaskStatus]
    public string Status { get; set; } = string.Empty;

    /// <summary>
    ///  タスクの期限を取得または設定します。
    /// </summary>
    [DataType(DataType.Date)]
    public DateTime? DueDate { get; set; }

    /// <summary>
    ///  タスクのステータス一覧を取得します。
    /// </summary>
    public List<SelectListItem> StatusList { get; }
}
