﻿// -----------------------------------------------------------------------
// <copyright file="ErrorViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex08.Models;

public class ErrorViewModel
{
    /// <summary>
    ///  <see cref="ErrorViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public ErrorViewModel()
    {
    }

    /// <summary>
    ///  リクエスト ID を取得または設定します。
    /// </summary>
    public string? RequestId { get; set; }

    /// <summary>
    ///  リクエスト ID を表示するかどうか示す値を取得します。
    /// </summary>
    public bool ShowRequestId => !string.IsNullOrEmpty(this.RequestId);
}
