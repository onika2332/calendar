﻿// -----------------------------------------------------------------------
// <copyright file="ErrorController.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using System.Diagnostics;
using Ex04.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ex04.Controllers;

/// <summary>
///  エラー画面を表示するためのコントローラーです。
/// </summary>
public class ErrorController : Controller
{
    /// <summary>
    ///  エラー画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>エラー画面のビュー。</returns>
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Index()
    {
        return this.View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? this.HttpContext.TraceIdentifier });
    }
}
