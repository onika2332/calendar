﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementDbContext.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Ex09.Data;

/// <summary>
///  ユーザー情報を管理する DbContext です。
/// </summary>
public class UserManagementDbContext : IdentityDbContext
{
    /// <summary>
    ///  <see cref="UserManagementDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public UserManagementDbContext()
    {
    }

    /// <summary>
    ///  <see cref="UserManagementDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="options">この DbContext のオプション。</param>
    public UserManagementDbContext(DbContextOptions<UserManagementDbContext> options)
        : base(options)
    {
    }

    /// <inheritdoc/>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        ArgumentNullException.ThrowIfNull(optionsBuilder);

        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=Ex09.UserManagement;Integrated Security=True");
        }
    }

    /// <inheritdoc/>
    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<IdentityUser>(entity =>
        {
            // パスワードはどちらのユーザーも「P@ssw0rd」です。
            entity.HasData(
                new IdentityUser
                {
                    Id = "06b5dc2b-2bbc-4824-8f65-b0c1415005bb",
                    UserName = "ドットネット基礎",
                    NormalizedUserName = "DOTNET-BASIC@BIPROGY.COM",
                    Email = "dotnet-basic@biprogy.com",
                    NormalizedEmail = "DOTNET-BASIC@BIPROGY.COM",
                    EmailConfirmed = false,
                    PasswordHash = "AQAAAAEAACcQAAAAEMvRCd7ziLi+1ODTDh+RFO0/y34uRjKPM5FaMmQUPcQb6/mWiyM9QyV6KV0Pkm7aEQ==",
                    SecurityStamp = "IFPUETPQWHMAI3BZHGIRP6DYCQQFX2KC",
                    ConcurrencyStamp = "15c1b245-de18-4ddd-9688-84cd94d47307",
                    PhoneNumber = null,
                    PhoneNumberConfirmed = false,
                    TwoFactorEnabled = false,
                    LockoutEnd = null,
                    LockoutEnabled = true,
                    AccessFailedCount = 0,
                },
                new IdentityUser
                {
                    Id = "31c18b1c-d503-49f2-86d6-0cf7d75ba18c",
                    UserName = "ハッピー.NET",
                    NormalizedUserName = "HAPPY-DOTNET@BIPROGY.COM",
                    Email = "happy-dotnet@biprogy.com",
                    NormalizedEmail = "HAPPY-DOTNET@BIPROGY.COM",
                    EmailConfirmed = false,
                    PasswordHash = "AQAAAAEAACcQAAAAEOODqGQql6jNpimg3lTu/pxBwJgcPASGiJkdaH5g8+nJx4pFgurCJX7ika2jioQ7jA==",
                    SecurityStamp = "7NAXKGYH4WWSQ7C4GSO6FQB4SIK62ZTU",
                    ConcurrencyStamp = "f662f828-f271-4631-83e4-7df084d9aef7",
                    PhoneNumber = null,
                    PhoneNumberConfirmed = false,
                    TwoFactorEnabled = false,
                    LockoutEnd = null,
                    LockoutEnabled = true,
                    AccessFailedCount = 0,
                });
        });
    }
}
