﻿// -----------------------------------------------------------------------
// <copyright file="EventIds.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex09;

/// <summary>
///  このプロジェクトで利用するイベント ID の一覧を管理します。
/// </summary>
internal class EventIds
{
    /// <summary>
    ///  イベントを登録したことを表すイベント ID (100) です。
    /// </summary>
    internal static readonly EventId EventRegistered = new(100);

    /// <summary>
    ///  イベントを更新したことを表すイベント ID (101) です。
    /// </summary>
    internal static readonly EventId EventUpdated = new(101);

    /// <summary>
    ///  イベントを削除したことを表すイベント ID (102) です。
    /// </summary>
    internal static readonly EventId EventDeleted = new(102);

    /// <summary>
    ///  イベントに誰かが参加登録したことを表すイベント ID (200) です。
    /// </summary>
    internal static readonly EventId JoinToEvent = new(200);
}
