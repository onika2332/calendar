﻿namespace Ex02.Models.Todo;

public class IndexViewModel
{
    public List<TaskViewModel> Tasks { get; set; }

    public IndexViewModel()
    {
        this.Tasks = new List<TaskViewModel>();
    }

}
