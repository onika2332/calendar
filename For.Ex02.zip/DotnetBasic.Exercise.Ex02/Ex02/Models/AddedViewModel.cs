﻿using System.ComponentModel.DataAnnotations;

namespace Ex02.Models;

public class AddedViewModel
{
    

}
