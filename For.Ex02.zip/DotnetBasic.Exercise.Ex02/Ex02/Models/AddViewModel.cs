﻿using System.ComponentModel.DataAnnotations;

namespace Ex02.Models;

public class AddViewModel
{
    [Required(ErrorMessage = "タスクのタイトルの入力は必須です。")]
    [MaxLength(128)]
    public string Title { get; set; }
}
