﻿namespace Ex02.Models.Todo;

public class TaskViewModel
{
    public string Title { get; set; }

    public string Status { get; set; }

    public int Id { get; set; }

    public TaskViewModel(int id, string title, string status)
    {
        this.Id = id;
        this.Title = title;
        this.Status = status;
    }
}
