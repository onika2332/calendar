﻿using Ex02.Models.Todo;
using Microsoft.AspNetCore.Mvc;

namespace Ex02.Controllers;
public class TodoController : Controller
{
    public IActionResult Index()
    {
        
        IndexViewModel list = new IndexViewModel();
        list.Tasks.Add(new TaskViewModel(100, "abcsdfkafk111", "done"));
        list.Tasks.Add(new TaskViewModel(200, "abcsdfkafk222", "adasdads222"));
        list.Tasks.Add(new TaskViewModel(300, "abcsdfkafk333", "done"));
        list.Tasks.Add(new TaskViewModel(400, "abcsdfkafk444", "adasdads444"));

        
        return this.View(list);
    }

    public IActionResult Add()
    {
        return this.View();
    }
}
