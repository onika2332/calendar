﻿using CRUD111.DataContext;
using CRUD111.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUD111.Controllers
{
    public class BookController : Controller
    {
        private readonly CRUD111Context _context;
        public BookController(CRUD111Context context)
        {
            this._context = context;
        }
        public IActionResult Index()
        {
            var books = this._context.Books.Include(x => x.Category).Where(x => !x.IsDeleted).ToList();
            return View(books);
        }

        // GET, POST : For Create action
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Category = this._context.Categories.Where(x => !x.IsDeleted).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Book BookModel)
        {
            this._context.Books.Add(BookModel);
            this._context.SaveChanges();

            return RedirectToAction("Index", "Book");
        }

        // GET, POST : Update action - Go on here !!!

        // GET : Delete action - Go on here!!!
    }
}
