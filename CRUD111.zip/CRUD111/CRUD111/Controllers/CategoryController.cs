﻿using CRUD111.DataContext;
using CRUD111.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUD111.Controllers
{
    public class CategoryController : Controller
    {
        private readonly CRUD111Context _context;

        public CategoryController(CRUD111Context context)
        {
            this._context = context;
        }
        
        // GET : For Index action
        public IActionResult Index()
        {
            var categories = this._context.Categories.Where(x => !x.IsDeleted).ToList();
            return View(categories);
        }

        // GET, POST : For Create action
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Category CategoryModel) {
            this._context.Categories.Add(CategoryModel);
            this._context.SaveChanges();

            return RedirectToAction("Index", "Category");
        }

        // GET, POST : Update action 
        [HttpGet]
        public IActionResult Update(int categoryId)
        {
            var model = this._context.Categories.Find(categoryId);
            return View(model);
        }
        [HttpPost]
        public IActionResult Update(Category model)
        {
            this._context.Categories.Update(model);
            this._context.SaveChanges();

            return RedirectToAction("Index", "Category");
        }

        // GET : Delete Action (??? : If you delete an category, what happen with books belong to this category??)
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = this._context.Categories.Find(id);
            model.IsDeleted = true;
            this._context.SaveChanges();

            return RedirectToAction("Index", "Category");
        }

    }
}
