﻿using Microsoft.EntityFrameworkCore;
using CRUD111.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace CRUD111.DataContext
{
    public class CRUD111Context : DbContext
    {
        public CRUD111Context(DbContextOptions options) : base(options) { }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Book> Books { get; set; }
    }

    // (??? : If you update an category, what happen with books belong to this category??)
        /*
         * That is solution issued by chatGPT (in DbContext type class)
         * First, mark [ForeignKey("parentId")] in Child model
         * protected override void OnModelCreating(ModelBuilder modelBuilder) {
         *      modelBuilder.Entity<Child>()
         *      .HasOne(c => c.Parent)
         *      .WithMany(p => p.Children)
         *      .HasForeignKey(c => c.ParentId)
         *      .OnDelete(DeleteBehavior.Cascade); // or DeleteBehavior.Restrict, DeleteBehavior.SetNull, etc..
         * }
         * 
         * ----Explain-----
         * - Cascade: When the principal (parent) entity is deleted, the dependent (child) entities are also deleted.
         * - Restrict: Prevents the deletion of the principal entity if related entities exist.
         * - SetNull: When the principal entity is deleted, the foreign key in the dependent entities is set to null.
         * - NoAction: No action is taken on the dependent entities. This is usually used with a database that supports this behavior.
         * ----------------
         */
}
