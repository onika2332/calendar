﻿// -----------------------------------------------------------------------
// <copyright file="AddViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using System.ComponentModel.DataAnnotations;

namespace Ex03.Models.Todo;

/// <summary>
///  TodoController の Add アクションメソッドが利用するビューのビューモデルです。
/// </summary>
public class AddViewModel
{
    /// <summary>
    ///  <see cref="AddViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>

    [Required(ErrorMessage= "タスクのタイトルは 3 文字以上 128 文字以内で入力してください。")]
    [MaxLength(128)]
    [MinLength(3)]
    public string Title { get; set; }
    

}
