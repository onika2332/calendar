﻿// -----------------------------------------------------------------------
// <copyright file="TodoController.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Ex03.Models.Todo;
using Microsoft.AspNetCore.Mvc;

namespace Ex03.Controllers;

/// <summary>
///  To-Do リストを提供するコントローラーです。
/// </summary>
public class TodoController : Controller
{
    /// <summary>
    ///  To-Do リストの初期画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>To-Do リスト画面のビュー。</returns>
    

    [HttpGet]
    public IActionResult Index()
    {
        // 表示するデータはアクションメソッド内で作成したダミーデータを使用します。
        var model = new IndexViewModel();
        model.Tasks.Add(new TaskViewModel() { Id = 101, Title = "タスク1", Status = "To do" });
        model.Tasks.Add(new TaskViewModel() { Id = 102, Title = "タスク2", Status = "In progress" });
        model.Tasks.Add(new TaskViewModel() { Id = 103, Title = "タスク3", Status = "To do" });
        model.Tasks.Add(new TaskViewModel() { Id = 104, Title = "タスク4", Status = "Done" });
        model.Tasks.Add(new TaskViewModel() { Id = 105, Title = "タスク5", Status = "In progress" });
        model.Tasks.Add(new TaskViewModel() { Id = 106, Title = "タスク6", Status = "Done" });
        return this.View(model);
    }

    [HttpGet]
    public IActionResult Add()
    {
        return this.View();
    }

    [HttpPost]
    public IActionResult Add(string Title) {
        AddedViewModel newAddedTask = new AddedViewModel() { Title = Title };
        Console.WriteLine(string.Format("タイトル：{0}", newAddedTask.Title));
        return this.RedirectToRoute(new
        {
            controller = "Todo",
            action = "Added",
            newTask = newAddedTask.Title
        });
    }

    [HttpGet]
    public IActionResult Added(string newTask)
    {
        
        return this.View(newTask);
    }

}
