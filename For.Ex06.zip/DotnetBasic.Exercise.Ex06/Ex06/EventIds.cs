﻿// -----------------------------------------------------------------------
// <copyright file="EventIds.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex06;

/// <summary>
///  このプロジェクトで利用するイベント ID の一覧を管理します。
/// </summary>
internal class EventIds
{
    /// <summary>
    ///  タスクを登録しようとしたことを表すイベント ID (100) です。
    /// </summary>
    internal static readonly EventId RegisterTask = new(100);

    /// <summary>
    ///  TempData から取得したタスクのタイトルが null だったことを表すイベント ID (200) です。
    /// </summary>
    internal static readonly EventId TaskTitleIsNull = new(200);
}
