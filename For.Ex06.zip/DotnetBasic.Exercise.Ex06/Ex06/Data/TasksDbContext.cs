﻿// -----------------------------------------------------------------------
// <copyright file="TasksDbContext.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Microsoft.EntityFrameworkCore;

namespace Ex06.Data;

/// <summary>
///  To Do リストを管理する DbContext です。
/// </summary>
public class TasksDbContext : DbContext
{
    /// <summary>
    ///  <see cref="TasksDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public TasksDbContext()
    {
    }

    /// <summary>
    ///  <see cref="TasksDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="options">この DbContext のオプション。</param>
    public TasksDbContext(DbContextOptions<TasksDbContext> options)
        : base(options)
    {
    }

    /// <summary>
    ///  タスクの一覧を取得します。
    /// </summary>
    public DbSet<TaskItem> Tasks { get; set; }

    /// <inheritdoc/>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        ArgumentNullException.ThrowIfNull(optionsBuilder);

        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=Ex06.TodoManagement;Integrated Security=True");
        }
    }
}
