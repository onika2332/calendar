﻿// -----------------------------------------------------------------------
// <copyright file="TodoController.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Ex05.Models.Todo;
using Microsoft.AspNetCore.Mvc;

namespace Ex05.Controllers;

/// <summary>
///  To-Do リストを提供するコントローラーです。
/// </summary>
public class TodoController : Controller
{
    private readonly ILogger<TodoController> logger;

    /// <summary>
    ///  <see cref="TodoController"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="logger">ロガー。</param>
    public TodoController(ILogger<TodoController> logger)
    {
        this.logger = logger;
    }

    /// <summary>
    ///  登録したタスクのタイトルを取得または設定します。
    /// </summary>
    [TempData]
    public string? NewTitle { get; set; }

    /// <summary>
    ///  To-Do リストの初期画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>To-Do リスト画面のビュー。</returns>
    [HttpGet]
    public IActionResult Index()
    {
        // 表示するデータはアクションメソッド内で作成したダミーデータを使用します。
        var model = new IndexViewModel();
        model.Tasks.Add(new TaskViewModel() { Id = 101, Title = "タスク1", Status = "To do" });
        model.Tasks.Add(new TaskViewModel() { Id = 102, Title = "タスク2", Status = "In progress" });
        model.Tasks.Add(new TaskViewModel() { Id = 103, Title = "タスク3", Status = "To do" });
        model.Tasks.Add(new TaskViewModel() { Id = 104, Title = "タスク4", Status = "Done" });
        model.Tasks.Add(new TaskViewModel() { Id = 105, Title = "タスク5", Status = "In progress" });
        model.Tasks.Add(new TaskViewModel() { Id = 106, Title = "タスク6", Status = "Done" });
        return this.View(model);
    }

    /// <summary>
    ///  タスクの登録画面を表示するアクションメソッドです。
    /// </summary>
    /// <returns>タスク登録画面のビュー。</returns>
    [HttpGet]
    public IActionResult Add()
    {
        var model = new AddViewModel();
        return this.View(model);
    }

    /// <summary>
    ///  タスクの登録を行うアクションメソッドです。
    /// </summary>
    /// <param name="model">登録するタスクの情報が設定されたビューモデル。</param>
    /// <returns><see cref="Added"/> アクションメソッドへのリダイレクト。</returns>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Add(AddViewModel model)
    {
        this.logger.LogDebug(
            EventIds.RegisterTask,
            $"タスク「{model}」を登録します。");
        if (!this.ModelState.IsValid)
        {
            return this.View(model);
        }

        this.NewTitle = model.Title;
        return this.RedirectToAction(nameof(this.Added));
    }

    /// <summary>
    ///  登録したタスクの情報を表示するアクションメソッドです。
    /// </summary>
    /// <returns>登録したタスクの情報を表示する画面のビュー。</returns>
    [HttpGet]
    public IActionResult Added()
    {
        if (this.NewTitle == null)
        {
            this.logger.LogInformation(
                EventIds.TaskTitleIsNull,
                $"タスクのタイトルが未設定のため、登録画面にリダイレクトします。");
            return this.RedirectToAction(nameof(this.Add));
        }

        var model = new AddedViewModel
        {
            Title = this.NewTitle,
        };
        return this.View(model);
    }
}
