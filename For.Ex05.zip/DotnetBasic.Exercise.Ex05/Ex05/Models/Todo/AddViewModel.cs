﻿// -----------------------------------------------------------------------
// <copyright file="AddViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using System.ComponentModel.DataAnnotations;

namespace Ex05.Models.Todo;

/// <summary>
///  TodoController の Add アクションメソッドが利用するビューのビューモデルです。
/// </summary>
public class AddViewModel
{
    /// <summary>
    ///  <see cref="AddViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public AddViewModel()
    {
    }

    /// <summary>
    ///  作成するタスクのタイトルを取得または設定します。
    /// </summary>
    [StringLength(maximumLength: 128, MinimumLength = 3, ErrorMessage = "タスクのタイトルは 3 文字以上 128 文字以内で入力してください。")]
    [Required(ErrorMessage = "タスクのタイトルの入力は必須です。")]
    public string Title { get; set; } = string.Empty;

    /// <inheritdoc/>
    public override string ToString()
    {
        return $"タイトル:{this.Title}";
    }
}
