﻿// -----------------------------------------------------------------------
// <copyright file="TasksDbContext.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

using Microsoft.EntityFrameworkCore;

namespace Ex07.Data;

/// <summary>
///  To Do リストを管理する DbContext です。
/// </summary>
public class TasksDbContext : DbContext
{
    /// <summary>
    ///  <see cref="TasksDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public TasksDbContext()
    {
    }

    /// <summary>
    ///  <see cref="TasksDbContext"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    /// <param name="options">この DbContext のオプション。</param>
    public TasksDbContext(DbContextOptions<TasksDbContext> options)
        : base(options)
    {
    }

    /// <summary>
    ///  タスクの一覧を取得します。
    /// </summary>
    public DbSet<TaskItem> Tasks { get; set; }

    /// <inheritdoc/>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        ArgumentNullException.ThrowIfNull(optionsBuilder);

        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=Ex07.TodoManagement;Integrated Security=True");
        }
    }

    /// <inheritdoc/>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TaskItem>(entity =>
        {
            entity.Property(taskItem => taskItem.Title)
                .IsRequired()
                .HasMaxLength(128);
            entity.Property(taskItem => taskItem.Status)
                .IsRequired()
                .HasMaxLength(32);

            entity.HasData(
                new TaskItem { Id = 1, Title = "演習1の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-6) },
                new TaskItem { Id = 2, Title = "演習2の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-5) },
                new TaskItem { Id = 3, Title = "演習3の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-4) },
                new TaskItem { Id = 4, Title = "演習4の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-3) },
                new TaskItem { Id = 5, Title = "演習5の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-2) },
                new TaskItem { Id = 6, Title = "演習6の完了", Status = TaskStatus.Done, DueDate = DateTime.Now.AddDays(-1) },
                new TaskItem { Id = 7, Title = "演習7の完了", Status = TaskStatus.InProgress, DueDate = DateTime.Now },
                new TaskItem { Id = 8, Title = "演習8の完了", Status = TaskStatus.ToDo, DueDate = DateTime.Now.AddDays(2) },
                new TaskItem { Id = 9, Title = "資格試験を受ける", Status = TaskStatus.ToDo, DueDate = null });
        });
    }
}
