﻿// -----------------------------------------------------------------------
// <copyright file="TaskItem.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex07.Data;

/// <summary>
///  1 件のタスクを表すテーブルエンティティです。
/// </summary>
public class TaskItem
{
    /// <summary>
    ///  タスクの ID を取得または設定します。
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    ///  タスクのタイトルを取得または設定します。
    ///  初期値は空の文字列 ("") です。
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    ///  タスクのステータスを取得または設定します。
    ///  初期値は "To do" です。
    /// </summary>
    public string Status { get; set; } = "To do";

    /// <summary>
    ///  タスクの期限を取得または設定します。
    /// </summary>
    public DateTime? DueDate { get; set; }
}
