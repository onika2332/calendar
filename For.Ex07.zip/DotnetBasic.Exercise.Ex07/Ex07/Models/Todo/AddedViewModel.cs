﻿// -----------------------------------------------------------------------
// <copyright file="AddedViewModel.cs" company="BIPROGY Inc.">
//  Copyright (c) 2023 BIPROGY Inc. All rights reserved.
//  BIPROGY INTERNAL USE ONLY.
// </copyright>
// -----------------------------------------------------------------------

namespace Ex07.Models.Todo;

/// <summary>
///  TodoController の Added アクションメソッドが利用するビューのビューモデルです。
/// </summary>
public class AddedViewModel
{
    /// <summary>
    ///  <see cref="AddedViewModel"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public AddedViewModel()
    {
    }

    /// <summary>
    ///  作成したタスクのタイトルを取得または設定します。
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    ///  作成したタスクの期限を取得または設定します。
    /// </summary>
    public DateTime? DueDate { get; set; }
}
