﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ex07.Migrations
{
    public partial class AddInitialData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Tasks",
                columns: new[] { "Id", "DueDate", "Status", "Title" },
                values: new object[,]
                {
                    { 1, DateTime.Now.AddDays(-6), "Done", "演習1の完了" },
                    { 2, DateTime.Now.AddDays(-5), "Done", "演習2の完了" },
                    { 3, DateTime.Now.AddDays(-4), "Done", "演習3の完了" },
                    { 4, DateTime.Now.AddDays(-3), "Done", "演習4の完了" },
                    { 5, DateTime.Now.AddDays(-2), "Done", "演習5の完了" },
                    { 6, DateTime.Now.AddDays(-1), "Done", "演習6の完了" },
                    { 7, DateTime.Now, "In progress", "演習7の完了" },
                    { 8, DateTime.Now.AddDays(2), "To do", "演習8の完了" },
                    { 9, null, "To do", "資格試験を受ける" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 9);
        }
    }
}
